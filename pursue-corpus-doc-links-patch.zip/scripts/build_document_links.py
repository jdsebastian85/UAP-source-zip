#!/usr/bin/env python3
"""Derive spine/document_links.csv from a raw Google Drive listing, and stamp
manifest.csv's working_url column (T2.6, document side).

Counterpart to build_media_links.py. Layer 0 sidecar: the join key is
release_id and this script does not touch ingest output.

Input  : spine/drive_listing_documents_<date>.tsv
         (drive_file_id, drive_title, drive_parent_id) — captured verbatim
         from the Drive API. Nothing in it is inferred.
Output : spine/document_links.csv, and manifest.csv's working_url column.

Matching note: unlike media (release_id == filename stem, exact), Drive
titles for documents do not always equal manifest.csv's source_file byte for
byte. Several families (CIA-UAP-0xx, FBI-UAP-D0xx, some DOW-UAP-Dxx, ICA-UAP-
D001) have the description portion of the filename re-punctuated somewhere
between the original release and what is now in the Drive folder — hyphens
in manifest.csv, underscores in Drive. Confirmed on the 2026-08-15 listing:
this is a punctuation difference only, not a content difference (same
release, same page count implied by the same ID token). The join below
normalizes both sides (lowercase, strip everything but alphanumerics) before
matching, and refuses to guess: any Drive title with zero or more than one
normalized match against manifest.csv is reported and excluded rather than
resolved silently.

Link tiers (see spine/SPINE.md):
  source_url   war.gov      primary provenance, may vanish     (not yet populated)
  mirror_url   archive.org  permanent public citation          (not yet populated)
  working_url  Drive        immediate access, not a citation   (populated here, LINKED rows only)
"""
import csv, os, re, sys, glob

SP = os.environ.get("SPINE", "spine")

VIEW = "https://drive.google.com/file/d/{id}/view"
EMBED = "https://drive.google.com/file/d/{id}/preview"
DIRECT = "https://drive.usercontent.google.com/download?id={id}&export=download&confirm=t"

COLS = ["release_id", "spine_status", "drive_file_id", "drive_parent_id",
        "working_view_url", "working_embed_url", "working_direct_url",
        "listed_utc", "source_url", "mirror_url"]

LINK_COLS = ["source_url", "mirror_url", "working_url"]


def norm(s):
    s = re.sub(r"\.pdf$", "", s, flags=re.I)
    return re.sub(r"[^a-z0-9]", "", s.lower())


def stamp_manifest(links):
    """Same mechanism as build_media_links.py's stamp_links, applied only to
    manifest.csv (documents have no media.csv-equivalent second file)."""
    path = os.path.join(SP, "manifest.csv")
    rows = list(csv.DictReader(open(path)))
    if not rows:
        return 0, 0
    cols = [c for c in rows[0].keys() if c not in LINK_COLS] + LINK_COLS
    filled = 0
    for r in rows:
        vals = links.get(r["release_id"], {})
        for c in LINK_COLS:
            r[c] = vals.get(c, r.get(c, ""))
        if r.get("working_url"):
            filled += 1
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)
    return len(rows), filled


def main():
    listings = sorted(glob.glob(os.path.join(SP, "drive_listing_documents_*.tsv")))
    if not listings:
        sys.exit(f"no {SP}/drive_listing_documents_*.tsv found")
    path = listings[-1]
    listed = os.path.basename(path).removeprefix("drive_listing_documents_").removesuffix(".tsv")

    man = list(csv.DictReader(open(os.path.join(SP, "manifest.csv"))))
    by_norm = {}
    for r in man:
        by_norm.setdefault(norm(r["source_file"]), []).append(r["release_id"])
    dupes = {k: v for k, v in by_norm.items() if len(v) > 1}
    if dupes:
        sys.exit(f"manifest.csv: {len(dupes)} normalized source_file collisions — "
                  f"cannot join safely: {list(dupes.items())[:3]}")

    seen_ids, matched, unmatched = set(), {}, []
    for r in csv.DictReader(open(path), delimiter="\t"):
        fid, title = r["drive_file_id"], r["drive_title"]
        hits = by_norm.get(norm(title), [])
        if len(hits) != 1:
            unmatched.append(title)
            continue
        rid = hits[0]
        if rid in seen_ids:
            sys.exit(f"duplicate release_id resolved twice: {rid}")
        seen_ids.add(rid)
        matched[rid] = {
            "release_id": rid, "spine_status": "LINKED", "drive_file_id": fid,
            "drive_parent_id": r["drive_parent_id"],
            "working_view_url": VIEW.format(id=fid),
            "working_embed_url": EMBED.format(id=fid),
            "working_direct_url": DIRECT.format(id=fid),
            "listed_utc": listed, "source_url": "", "mirror_url": "",
        }

    if unmatched:
        print(f"WARN: {len(unmatched)} Drive titles matched no manifest row "
              f"(or matched more than one): {unmatched[:5]}")

    rows = []
    for r in man:
        rid = r["release_id"]
        rows.append(matched.get(rid, {
            "release_id": rid, "spine_status": "ZIPPED", "drive_file_id": "",
            "drive_parent_id": "", "working_view_url": "", "working_embed_url": "",
            "working_direct_url": "", "listed_utc": listed, "source_url": "", "mirror_url": "",
        }))

    out = os.path.join(SP, "document_links.csv")
    with open(out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=COLS)
        w.writeheader()
        w.writerows(rows)

    n_linked = sum(1 for r in rows if r["spine_status"] == "LINKED")
    print(f"{out}: {len(rows)} rows  LINKED {n_linked}  ZIPPED {len(rows) - n_linked}")

    links = {rid: {"source_url": v["source_url"], "mirror_url": v["mirror_url"],
                    "working_url": v["working_view_url"]} for rid, v in matched.items()}
    n, filled = stamp_manifest(links)
    print(f"manifest.csv: {n} rows stamped with {'/'.join(LINK_COLS)}, {filled} with a working link")


if __name__ == "__main__":
    main()
